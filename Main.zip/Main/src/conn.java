
import java.sql.*;
/**
 *
 * @author dell
 */
public class conn {
    private Connection con;
   public Statement st;
   ResultSet rs;
   
   
   
   public conn(){
       try {
            Class.forName("com.mysql.cj.jdbc.Driver");
           con=DriverManager.getConnection("jdbc:mysql://localhost:3306/lms","root","");
           st=con.createStatement();
           System.out.println("Database Connected");
       } catch (Exception ex) {
           System.out.println(ex);
       }
}
}

    

